// header comment
public class Die
{
   // properties
   int currentFaceValueOfTheDie;

   // constructors

   // methods
   public int roll()
   {
      // variables      
                           
      // program code
      
// Calculate current dice number with Math.random method and return it.
      currentFaceValueOfTheDie = ( int ) ( ( Math.random() * 6 ) + 1 );                       
      return currentFaceValueOfTheDie;
   } //end of roll method 

// It shows current face value of the die.   
   public int getFaceValue()
   {  
      return currentFaceValueOfTheDie;
   } // end of get face value method
   
   public String toString()
   {
      // variables
      String result;
      
      //program code
      result = "" + "Current face value of the die is " + currentFaceValueOfTheDie; 
      
      return result;
   }   
}