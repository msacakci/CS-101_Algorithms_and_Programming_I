import java.util.Scanner;

/**
 * Let's Roll Dice
 * @author Metehan Sa�ak��
 * @version 24.11.2019
 */ 
public class TestDiceGame
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      DiceGame dicegame;      

      // program code
      dicegame = new DiceGame();
      
      System.out.println( dicegame.play());

   }

} // end class